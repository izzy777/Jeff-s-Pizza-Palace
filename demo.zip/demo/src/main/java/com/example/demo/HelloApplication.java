package com.example.demo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.scene.text.*;
import javafx.scene.effect.*;
import javafx.scene.control.*;

import javafx.event.*;

import java.io.IOException;
import java.util.List;

public class HelloApplication extends Application {
    private Stage stage;
    private double screenWidth = 800;
    private double screenHeight = 600;
    private double headerFontSize = 16;
    private double buttonFontSize = 12;

    private Button backButton = new Button("Back");

    private String lookupNum;

    @Override
    public void start(Stage firstStage) throws IOException {
        //FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        //Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        backButton.setPrefWidth(100);
        backButton.setPrefHeight(20);
        backButton.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 16));
        backButton.setLayoutX(15);
        backButton.setLayoutY(550);
        stage = firstStage;
        Scene scene = startupScene();
        stage.setTitle("Jeff's Pizza Palace");
        stage.setScene(scene);
        stage.show();
    }

    /*
    Scene 1.0
    Access this scene by starting the program or hitting the back button on either
    the new order phone number scene (1.2) or managerViewScene (1.1)
     */
    public Scene startupScene()
    {
        Group root = new Group();
        Scene scene = new Scene(root, screenWidth, screenHeight, Color.LIGHTPINK);
        //DropShadow shadow = new DropShadow(5, -7, 7, Color.HOTPINK);
        Text title = new Text();
        title.setText("Jeff's Pizza Palace");
        title.setX(screenWidth / 4);
        title.setY(175);
        title.setFont(Font.font("Brush Script MT", FontWeight.BOLD, FontPosture.REGULAR, 64));
        title.setFill(Color.WHITE);
        title.setStroke(Color.DEEPPINK);
        title.setStrokeWidth(3);
        title.setStrokeType(StrokeType.OUTSIDE);
        //title.setEffect(shadow);

        Button managerButton = new Button("Manager Access");
        managerButton.setLayoutX(300);
        managerButton.setLayoutY(320);
        managerButton.setPrefWidth(200);
        managerButton.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 18));
        managerButton.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t){
                stage.setScene(managerViewScene());
            }
        });

        Button orderButton = new Button("Create New Order");
        orderButton.setLayoutX(300);
        orderButton.setLayoutY(370);
        orderButton.setPrefWidth(200);
        orderButton.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 18));
        orderButton.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(createPhoneNumScene());
            }
        });

        root.getChildren().add(managerButton);
        root.getChildren().add(orderButton);
        root.getChildren().add(title);

        return scene;
    }

    /*
    Scene 1.1
    Access this scene from the startup scene (1.0) and by pressing the back button
    on the customer info screen (1.1.1)
     */
    public Scene managerViewScene()
    {
        Group root = new Group();
        Scene scene = new Scene(root, screenWidth, screenHeight, Color.LIGHTPINK);

        Rectangle titleBG = new Rectangle(50, 160, screenWidth - 100, 60);
        titleBG.setFill(Color.HOTPINK);
        titleBG.setStroke(Color.DEEPPINK);
        titleBG.setStrokeWidth(4);
        root.getChildren().add(titleBG);

        Text title = new Text(150, 200, "Enter customer phone number");
        title.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 32));
        title.setFill(Color.WHITE);
        root.getChildren().add(title);

        TextField pn = new TextField();
        pn.setLayoutX(225);
        pn.setLayoutY(310);
        pn.setPrefWidth(350);
        pn.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 16));
        pn.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                //if pn.getText() is a valid phone number && exists in our database
                lookupNum = pn.getText();
                stage.setScene(displayCustomerScene());
                //else, display text that says that's an invalid number and let the user try again (don't switch scenes)
            }
        });
        root.getChildren().add(pn);

        backButton.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(startupScene());
            }
        });
        root.getChildren().add(backButton);

        return scene;
    }

    /*
    Scene 1.1.1
    Access this scene by entering a valid phone number on managerViewScene (1.1)
     */
    public Scene displayCustomerScene()
    {
        Group root = new Group();
        Scene scene = new Scene(root, screenWidth, screenHeight, Color.LIGHTPINK);

        Text title = new Text(240, 55, "Customer Information");
        title.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 32));
        root.getChildren().add(title);

        Rectangle infoRec = new Rectangle(50, 80, 325, 360);
        infoRec.setFill(Color.WHITE);
        root.getChildren().add(infoRec);

        Rectangle orderRec = new Rectangle(425, 80, 325, 360);
        orderRec.setFill(Color.WHITE);
        root.getChildren().add(orderRec);

        Text orderTitle = new Text(540, 110, "Orders");
        orderTitle.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 24));
        orderTitle.setFill(Color.DEEPPINK);
        root.getChildren().add(orderTitle);

        Text infoTitle = new Text(150,110,"Information");
        infoTitle.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 24));
        infoTitle.setFill(Color.DEEPPINK);
        root.getChildren().add(infoTitle);

        /*
        Insert reading the csv files in order to display the customer's information and
        orders on top of the respective rectangles. Template below:
         */

        Text custOrders = new Text();
        String ordersString = "";
        ordersString += "Pizza Size, Topping 1, Topping 2, Topping 3, Topping 4, Crust type, Beverage, Beverage size, Delivery/Pickup";
        custOrders.setText(ordersString);
        custOrders.setLayoutX(445);
        custOrders.setLayoutY(140);
        custOrders.setWrappingWidth(285);
        custOrders.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 14));
        root.getChildren().add(custOrders);

        Text custInfo = new Text();
        String infoString = "";
        infoString += "Name: \nEmail: \nStreet Address: \nCity: \nState: \nZip Code: \nLocation Info: \nCharge Account: ";
        custInfo.setText(infoString);
        custInfo.setLayoutX(70);
        custInfo.setLayoutY(140);
        custInfo.setWrappingWidth(285);
        custInfo.setLineSpacing(5);
        custInfo.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 14));
        root.getChildren().add(custInfo);

        backButton.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(managerViewScene());
            }
        });
        root.getChildren().add(backButton);

        return scene;
    }

    /*
    Scene 1.2
    Access this scene by choosing to create a new order on startupScene (1.0)
     */
    public Scene createPhoneNumScene()
    {
        Group root = new Group();
        Scene scene = new Scene(root, screenWidth, screenHeight, Color.LIGHTPINK);

        Rectangle titleBG = new Rectangle(100, 160, 600, 75);
        titleBG.setFill(Color.HOTPINK);
        titleBG.setStroke(Color.DEEPPINK);
        titleBG.setStrokeWidth(4);
        root.getChildren().add(titleBG);

        Text title = new Text(140, 200, "Enter phone number for new order:");
        title.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 32));
        title.setFill(Color.WHITE);
        root.getChildren().add(title);

        TextField pn = new TextField();
        pn.setLayoutX(225);
        pn.setLayoutY(310);
        pn.setPrefWidth(350);
        pn.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                //If returning customer's phone number, go straight to orderScene (1.3)
                //stage.setScene(orderScene());
                //Else (if phone number is not in database), go to newCustomerScene(1.2.1)
                stage.setScene(newCustomerScene());
            }
        });
        root.getChildren().add(pn);

        backButton.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(startupScene());
            }
        });
        root.getChildren().add(backButton);

        return scene;
    }

    /*
    Scene 1.2.1
    Access this scene if the phone number entered in scene 1.2 was not an existing customer's phone number
     */
    public Scene newCustomerScene()
    {
        Group root = new Group();
        Scene scene = new Scene(root, screenWidth, screenHeight, Color.LIGHTPINK);

        Rectangle titleBG = new Rectangle(100, 100, 600, 75);
        titleBG.setFill(Color.HOTPINK);
        titleBG.setStroke(Color.DEEPPINK);
        titleBG.setStrokeWidth(4);
        root.getChildren().add(titleBG);

        Text title = new Text(140, 140, "Enter new customer information");
        title.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 32));
        title.setFill(Color.WHITE);
        root.getChildren().add(title);

        Text custInfo = new Text();
        String infoString = "";
        infoString += "Name: \nEmail: \nStreet Address: \nCity: \nState: \nZip Code: \nLocation Info: \nCharge Account: ";
        custInfo.setText(infoString);
        custInfo.setLayoutX(140);
        custInfo.setLayoutY(240);
        custInfo.setWrappingWidth(285);
        custInfo.setLineSpacing(20);
        custInfo.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 16));
        root.getChildren().add(custInfo);

        TextField name = new TextField();
        name.setLayoutX(320);
        name.setLayoutY(230);
        name.setPrefWidth(200);
        root.getChildren().add(name);

        TextField email = new TextField();
        email.setLayoutX(320);
        email.setLayoutY(270);
        email.setPrefWidth(200);
        root.getChildren().add(email);

        TextField street = new TextField();
        street.setLayoutX(320);
        street.setLayoutY(310);
        street.setPrefWidth(200);
        root.getChildren().add(street);

        TextField city = new TextField();
        city.setLayoutX(320);
        city.setLayoutY(350);
        city.setPrefWidth(200);
        root.getChildren().add(city);

        TextField state = new TextField();
        state.setLayoutX(320);
        state.setLayoutY(390);
        state.setPrefWidth(200);
        root.getChildren().add(state);

        TextField zip = new TextField();
        zip.setLayoutX(320);
        zip.setLayoutY(430);
        zip.setPrefWidth(200);
        root.getChildren().add(zip);

        TextField loca = new TextField();
        loca.setLayoutX(320);
        loca.setLayoutY(470);
        loca.setPrefWidth(200);
        root.getChildren().add(loca);

        TextField acc = new TextField();
        acc.setLayoutX(320);
        acc.setLayoutY(510);
        acc.setPrefWidth(200);
        root.getChildren().add(acc);

        backButton.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(startupScene());
            }
        });
        root.getChildren().add(backButton);

        Button next = new Button("Next");
        next.setLayoutX(685);
        next.setLayoutY(550);
        next.setPrefWidth(100);
        next.setPrefHeight(20);
        next.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 16));
        next.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(orderScene());
            }
        });
        root.getChildren().add(next);

        return scene;
    }

    /*
    Scene 1.3
    Access this scene after inputting the customer's phone number in scene 1.2 (and inputting info in 1.2.1 if necessary)
     */
    public Scene orderScene()
    {
        double space;
        String toppings[] = {
                "No Topping", "Cheese", "Pepperoni", "Ham", "Bacon",
                "Anchovies", "Peppers", "Onion", "Olives", "Mushrooms"
        };
        String pizzaSizes[] = { "No Pizza", "Small +$11.00", "Medium +$13.00", "Large +$15.00" };
        String crusts[] = { "Hand-tossed +$0.00", "Thin +$0.00", "Stuffed +$1.00" };
        String drinks[] = {
                "No Drink", "Water", "Sweet Tea", "Lemonade",
                "Sprite", "Coke", "Mello Yello", "Princess Punch"
        };
        String drinkSizes[] = { "Small +$2.50", "Medium +$3.00", "Large +$3.25" };


        Group root = new Group();
        Scene scene = new Scene(root, screenWidth, screenHeight, Color.LIGHTPINK);

        Rectangle orderBG = new Rectangle(15,15,270,470);
        orderBG.setFill(Color.WHITE);
        root.getChildren().add(orderBG);

        Rectangle orderDivider = new Rectangle(286,15,3,570);
        orderDivider.setFill(Color.HOTPINK);
        root.getChildren().add(orderDivider);

        Rectangle totalBG = new Rectangle(15, 500, 270, 85);
        totalBG.setFill(Color.WHITE);
        root.getChildren().add(totalBG);

        Text orderTitle = new Text(30, 40, "Customer name");
        orderTitle.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        orderTitle.setFill(Color.DEEPPINK);
        root.getChildren().add(orderTitle);

        Text orderPhone = new Text(30, 60, "(123)-456-7890");
        orderPhone.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        orderPhone.setFill(Color.DEEPPINK);
        root.getChildren().add(orderPhone);

        Text itemizedOrder = new Text();
        String orderString = "Itemized order items to be read from the Order object's Menu objects";
        itemizedOrder.setText(orderString);
        itemizedOrder.setWrappingWidth(240);
        itemizedOrder.setLayoutX(30);
        itemizedOrder.setLayoutY(90);
        root.getChildren().add(itemizedOrder);

        Text totalTitle = new Text(130, 465, "Total: ");
        totalTitle.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 18));
        totalTitle.setFill(Color.DEEPPINK);
        root.getChildren().add(totalTitle);

        Text total = new Text();
        String totalString = "$0.00";
        total.setText(totalString);
        total.setLayoutX(200);
        total.setLayoutY(465);
        total.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 18));
        root.getChildren().add(total);

        Button payButton = new Button("Pay Now");
        payButton.setLayoutX(30);
        payButton.setLayoutY(520);
        payButton.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 22));
        payButton.setPrefWidth(240);
        payButton.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(paymentScene());
            }
        });
        root.getChildren().add(payButton);

        //-----Order option buttons
        Text pizzaSize = new Text(304, 30, "Pizza Size");
        pizzaSize.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(pizzaSize);

        space = 120;
        for (int i = 0; i < 4; i++)
        {
            String bText = pizzaSizes[i];
            Button b = new Button(bText);
            b.setLayoutX(304 + (space * i));
            b.setLayoutY(35);
            b.setPrefHeight(20);
            b.setPrefWidth(110);
            b.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, buttonFontSize));
            root.getChildren().add(b);
        }

        space = 85;
        for (int i = 0; i < 4; i++)
        {
            Text t = new Text("Toppings are an additional $1.50 each");
            t.setLayoutX(400);
            t.setLayoutY(85 + (space * i));
            t.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 14));
            root.getChildren().add(t);
        }

        Text topping1 = new Text(304, 85, "Topping 1");
        topping1.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(topping1);

        space = 96;
        double yspace = 28;
        for (int j = 0; j < 2; j++)
        {
            for (int k = 0; k < 5; k++)
            {
                String bText = toppings[k + (j * 5)];
                Button b = new Button(bText);
                b.setLayoutX(304 + (space * k));
                b.setLayoutY(90 + (yspace * j));
                b.setPrefHeight(20);
                b.setPrefWidth(86);
                b.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, buttonFontSize));
                root.getChildren().add(b);
            }
        }

        Text topping2 = new Text(304, 170, "Topping 2");
        topping2.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(topping2);

        for (int j = 0; j < 2; j++)
        {
            for (int k = 0; k < 5; k++)
            {
                String bText = toppings[k + (j * 5)];
                Button b = new Button(bText);
                b.setLayoutX(304 + (space * k));
                b.setLayoutY(175 + (yspace * j));
                b.setPrefHeight(20);
                b.setPrefWidth(86);
                b.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, buttonFontSize));
                // add to topping 2 attribute of order item
                root.getChildren().add(b);
            }
        }

        Text topping3 = new Text(304, 255, "Topping 3");
        topping3.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(topping3);

        for (int j = 0; j < 2; j++)
        {
            for (int k = 0; k < 5; k++)
            {
                String bText = toppings[k + (j * 5)];
                Button b = new Button(bText);
                b.setLayoutX(304 + (space * k));
                b.setLayoutY(260 + (yspace * j));
                b.setPrefHeight(20);
                b.setPrefWidth(86);
                b.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, buttonFontSize));
                // add to topping 3 attribute of order item
                root.getChildren().add(b);
            }
        }

        Text topping4 = new Text(304, 340, "Topping 4");
        topping4.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(topping4);

        for (int j = 0; j < 2; j++)
        {
            for (int k = 0; k < 5; k++)
            {
                String bText = toppings[k + (j * 5)];
                Button b = new Button(bText);
                b.setLayoutX(304 + (space * k));
                b.setLayoutY(345 + (yspace * j));
                b.setPrefHeight(20);
                b.setPrefWidth(86);
                b.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, buttonFontSize));
                // add to topping 4 attribute of order item
                root.getChildren().add(b);
            }
        }

        Text crust = new Text(304, 425, "Crust Style");
        crust.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(crust);

        space = 160;
        for (int i = 0; i < 3; i++)
        {
            Button b = new Button(crusts[i]);
            b.setLayoutX(304 + (space * i));
            b.setLayoutY(430);
            b.setPrefHeight(20);
            b.setPrefWidth(150);
            b.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, buttonFontSize));
            root.getChildren().add(b);
        }

        Text drink = new Text(304, 477, "Beverage");
        drink.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(drink);

        space = 120;
        for (int j = 0; j < 2; j++)
        {
            for (int k = 0; k < 4; k++)
            {
                String bText = drinks[k + (j * 4)];
                Button b = new Button(bText);
                b.setLayoutX(304 + (space * k));
                b.setLayoutY(482 + (yspace * j));
                b.setPrefHeight(20);
                b.setPrefWidth(110);
                b.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, buttonFontSize));
                root.getChildren().add(b);
            }
        }

        Text drinkSize = new Text(304, 555, "Drink Size");
        drinkSize.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(drinkSize);

        space = 160;
        for (int i = 0; i < 3; i++)
        {
            Button b = new Button(drinkSizes[i]);
            b.setLayoutX(304 + (space * i));
            b.setLayoutY(560);
            b.setPrefHeight(20);
            b.setPrefWidth(150);
            b.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, buttonFontSize));
            root.getChildren().add(b);
        }

        return scene;
    }

    /*
    Scene 1.4
    Access this scene by selecting "Pay Now" in scene 1.3
     */
    public Scene paymentScene()
    {
        Group root = new Group();
        Scene scene = new Scene(root, screenWidth, screenHeight, Color.LIGHTPINK);

        Rectangle paymentBG = new Rectangle(15,15,270,470);
        paymentBG.setFill(Color.WHITE);
        root.getChildren().add(paymentBG);

        Rectangle paymentDivider = new Rectangle(286,15,3,570);
        paymentDivider.setFill(Color.HOTPINK);
        root.getChildren().add(paymentDivider);

        Text title = new Text(30, 40, "Payment Method");
        title.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        title.setFill(Color.DEEPPINK);
        root.getChildren().add(title);

        Button cashButton = new Button("Cash");
        cashButton.setLayoutX(30);
        cashButton.setLayoutY(60);
        cashButton.setPrefSize(190, 20);
        cashButton.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        cashButton.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(cashScene());
            }
        });
        root.getChildren().add(cashButton);

        Button cardButton = new Button("Card");
        cardButton.setLayoutX(30);
        cardButton.setLayoutY(110);
        cardButton.setPrefSize(190, 20);
        cardButton.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        cardButton.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(cardScene());
            }
        });
        root.getChildren().add(cardButton);

        return scene;
    }

    /*
    Scene 1.4.1
    Access this scene by selecting Cash in scene 1.4
     */
    public Scene cashScene()
    {
        Group root = new Group();
        Scene scene = new Scene(root, screenWidth, screenHeight, Color.LIGHTPINK);

        Rectangle paymentBG = new Rectangle(15,15,270,570);
        paymentBG.setFill(Color.WHITE);
        root.getChildren().add(paymentBG);

        Rectangle paymentDivider = new Rectangle(286,15,3,570);
        paymentDivider.setFill(Color.HOTPINK);
        root.getChildren().add(paymentDivider);

        Rectangle infoBG = new Rectangle(315, 130, 450, 380);
        infoBG.setFill(Color.WHITE);
        root.getChildren().add(infoBG);

        Text title = new Text(30, 40, "Payment Method");
        title.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        title.setFill(Color.DEEPPINK);
        root.getChildren().add(title);

        Button cashButton = new Button("Cash");
        cashButton.setLayoutX(30);
        cashButton.setLayoutY(60);
        cashButton.setPrefSize(190, 20);
        cashButton.setTextFill(Color.DEEPPINK);
        cashButton.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(cashButton);

        Button cardButton = new Button("Card");
        cardButton.setLayoutX(30);
        cardButton.setLayoutY(110);
        cardButton.setPrefSize(190, 20);
        cardButton.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        cardButton.setDisable(true);
        root.getChildren().add(cardButton);

        Polygon triangle = new Polygon();
        triangle.getPoints().addAll(
                240.0, 65.0,
                240.0, 85.0,
                260.0, 75.0);
        triangle.setFill(Color.DEEPPINK);
        root.getChildren().add(triangle);

        Text del = new Text("Is this order for delivery or pickup?");
        del.setLayoutX(30);
        del.setLayoutY(200);
        del.setWrappingWidth(190);
        del.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(del);

        ChoiceBox<String> cb = new ChoiceBox<String>();
        cb.getItems().add("Delivery");
        cb.getItems().add("Pickup");
        cb.setLayoutX(30);
        cb.setLayoutY(230);
        root.getChildren().add(cb);

        Rectangle cashBG = new Rectangle(315, 30, 450, 80);
        cashBG.setFill(Color.HOTPINK);
        cashBG.setStroke(Color.DEEPPINK);
        cashBG.setStrokeWidth(4);
        root.getChildren().add(cashBG);

        Text cashTitle = new Text(335, 80, "Enter Payment Information");
        cashTitle.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 32));
        cashTitle.setFill(Color.WHITE);
        root.getChildren().add(cashTitle);

        Text total = new Text(345, 180, "Total: $0.00");
        total.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 24));
        root.getChildren().add(total);

        Button submit = new Button("Submit Payment");
        submit.setLayoutX(560);
        submit.setLayoutY(525);
        submit.setPrefSize(200, 30);
        submit.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        submit.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(receiptScene());
            }
        });
        root.getChildren().add(submit);

        return scene;
    }

    /*
    Scene 1.4.2
    Access this scene by selecting Card in scene 1.4
     */
    public Scene cardScene()
    {
        Group root = new Group();
        Scene scene = new Scene(root, screenWidth, screenHeight, Color.LIGHTPINK);

        Rectangle paymentBG = new Rectangle(15,15,270,570);
        paymentBG.setFill(Color.WHITE);
        root.getChildren().add(paymentBG);

        Rectangle paymentDivider = new Rectangle(286,15,3,570);
        paymentDivider.setFill(Color.HOTPINK);
        root.getChildren().add(paymentDivider);

        Rectangle infoBG = new Rectangle(315, 130, 450, 380);
        infoBG.setFill(Color.WHITE);
        root.getChildren().add(infoBG);

        Text title = new Text(30, 40, "Payment Method");
        title.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        title.setFill(Color.DEEPPINK);
        root.getChildren().add(title);

        Button cashButton = new Button("Cash");
        cashButton.setLayoutX(30);
        cashButton.setLayoutY(60);
        cashButton.setPrefSize(190, 20);
        cashButton.setDisable(true);
        cashButton.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(cashButton);

        Button cardButton = new Button("Card");
        cardButton.setLayoutX(30);
        cardButton.setLayoutY(110);
        cardButton.setPrefSize(190, 20);
        cardButton.setTextFill(Color.DEEPPINK);
        cardButton.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(cardButton);

        Polygon triangle = new Polygon();
        triangle.getPoints().addAll(
                240.0, 115.0,
                240.0, 135.0,
                260.0, 125.0);
        triangle.setFill(Color.DEEPPINK);
        root.getChildren().add(triangle);

        Text del = new Text("Is this order for delivery or pickup?");
        del.setLayoutX(30);
        del.setLayoutY(200);
        del.setWrappingWidth(190);
        del.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(del);

        ChoiceBox<String> cb = new ChoiceBox<String>();
        cb.getItems().add("Delivery");
        cb.getItems().add("Pickup");
        cb.setLayoutX(30);
        cb.setLayoutY(230);
        root.getChildren().add(cb);

        Rectangle cardBG = new Rectangle(315, 30, 450, 80);
        cardBG.setFill(Color.HOTPINK);
        cardBG.setStroke(Color.DEEPPINK);
        cardBG.setStrokeWidth(4);
        root.getChildren().add(cardBG);

        Text cardTitle = new Text(335, 80, "Enter Payment Information");
        cardTitle.setFont(Font.font("TW Cent MT", FontWeight.BOLD, FontPosture.REGULAR, 32));
        cardTitle.setFill(Color.WHITE);
        root.getChildren().add(cardTitle);

        Text total = new Text(345, 180, "Total: $0.00");
        total.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 24));
        root.getChildren().add(total);

        Text cardName = new Text(345, 220, "Name on card:");
        cardName.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 24));
        root.getChildren().add(cardName);

        Text cardNum = new Text(345, 260, "Card number:");
        cardNum.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 24));
        root.getChildren().add(cardNum);

        Text cvv = new Text(345, 300, "CVV:");
        cvv.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 24));
        root.getChildren().add(cvv);

        Text cardDate = new Text(345, 340, "Exp. Date:");
        cardDate.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, 24));
        root.getChildren().add(cardDate);



        Button submit = new Button("Submit Payment");
        submit.setLayoutX(560);
        submit.setLayoutY(525);
        submit.setPrefSize(200, 30);
        submit.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        submit.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(receiptScene());
            }
        });
        root.getChildren().add(submit);

        return scene;
    }

    /*
    Scene 1.5
    Access this scene by clicking submit payment in either scene 1.4.1 or 1.4.2
     */
    public Scene receiptScene()
    {
        Group root = new Group();
        Scene scene = new Scene(root, screenWidth, screenHeight, Color.LIGHTPINK);

        Rectangle receiptBG = new Rectangle(400, 20, 250, 560);
        receiptBG.setFill(Color.WHITE);
        root.getChildren().add(receiptBG);

        Text text = new Text();
        String textString = "   JEFF'S PIZZA PALACE\n\n" +
                "-------------------------\n\n" +
                "For: DELIVERY/PICKUP\n" +
                "Order Item         $00.00\n" +
                "Order Item         $00.00\n" +
                "Order Item         $00.00\n" +
                "Order Item         $00.00\n" +
                "Order Item         $00.00\n" +
                "Order Item         $00.00\n" +
                "Order Item         $00.00\n\n" +
                "TOTAL:             $00.00\n\n" +
                "-------------------------\n\n" +
                "Paid with: CASH/CREDIT\n\n" +
                "If CREDIT: Last 4 digits\n\n" +
                "SIGN X___________________\n\n" +
                "Thank you for dining with\n" +
                "royalty!";
        text.setText(textString);
        text.setFont(Font.font("Lucida Console", FontWeight.NORMAL, FontPosture.REGULAR, buttonFontSize));
        text.setLayoutX(435);
        text.setLayoutY(60);
        text.setLineSpacing(5);
        root.getChildren().add(text);

        Button startOverButton = new Button("Return to main menu");
        startOverButton.setLayoutX(50);
        startOverButton.setLayoutY(250);
        startOverButton.setPrefSize(300, 30);
        startOverButton.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        startOverButton.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent t) {
                stage.setScene(startupScene());
            }
        });
        root.getChildren().add(startOverButton);

        Button printButton = new Button("Print receipt");
        printButton.setLayoutX(50);
        printButton.setLayoutY(290);
        printButton.setPrefSize(300, 30);
        printButton.setFont(Font.font("TW Cent MT", FontWeight.NORMAL, FontPosture.REGULAR, headerFontSize));
        root.getChildren().add(printButton);

        return scene;
    }


    public static void main(String[] args) {
        launch();
    }
}