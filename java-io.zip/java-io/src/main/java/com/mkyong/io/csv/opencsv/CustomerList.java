package com.mkyong.io.csv.opencsv;

import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;

import java.io.*;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class CustomerList {

    private static boolean isLoaded;
    private static List<Customer> customers = new ArrayList<>();

    public static void add(Customer customer) throws CsvRequiredFieldEmptyException, CsvDataTypeMismatchException, IOException, URISyntaxException {

        if(!isLoaded) readCustomersFromCsv();

        customers.add(customer);
        writeCustomersToCsv();
    }

    //finds a customer by phone number, returns null if not found
    public static Customer get(String phone) throws IOException, URISyntaxException {
        if(!isLoaded) readCustomersFromCsv();

        return customers.stream()
                .filter(customer -> phone.equals(customer.getPhone()))
                .findAny()
                .orElse(null);
    }

    public static void showCustomerList() throws IOException, URISyntaxException {
        if(!isLoaded) readCustomersFromCsv();
        System.out.println("======================================");
        System.out.println("Customers in list: " + customers.size());
        for (Customer customer : customers)
        {
            System.out.println(customer);
            System.out.println(customer.getFirstName() + ", " + customer.getStreetAddress());
            System.out.println();
        }
        System.out.println("======================================");
        System.out.println();
        System.out.println();
    }

    private static void readCustomersFromCsv() throws IOException, URISyntaxException {
        URL resource = Customer.class.getClassLoader().getResource("csv/Customer.csv");
        File file = Paths.get(resource.toURI()).toFile();
        customers = new CsvToBeanBuilder(new FileReader(file.toString()))
                .withType(Customer.class)
                .build()
                .parse();

        System.out.println(customers.size() + " loaded from " + file);
        isLoaded = true;
    }

    private static void writeCustomersToCsv() throws IOException, URISyntaxException, CsvDataTypeMismatchException, CsvRequiredFieldEmptyException {

        URL resource = Customer.class.getClassLoader().getResource("csv/Customer.csv");
        File file = Paths.get(resource.toURI()).toFile();

        Writer writer  = new FileWriter(file.toString());

        StatefulBeanToCsv sbc = new StatefulBeanToCsvBuilder(writer)
                .withSeparator(CSVWriter.DEFAULT_SEPARATOR)
                .build();

        sbc.write(customers);
        writer.close();

        System.out.println(customers.size() + " written to " + file);
    }

}
