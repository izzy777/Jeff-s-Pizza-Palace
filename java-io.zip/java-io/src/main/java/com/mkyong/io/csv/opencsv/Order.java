package com.mkyong.io.csv.opencsv;

import com.opencsv.bean.CsvBindByPosition;

import java.util.UUID;

public class Order {
    private String header;
    private Menu[] PizzaOrder = new Menu[8]; //holds size, crust type, then 4 toppings
    @CsvBindByPosition(position = 2)
    private double total;
    @CsvBindByPosition(position = 1)
    private UUID OrderNo;
    private boolean isDelivery;
    @CsvBindByPosition(position = 0)
    private String phone;
    // Default constructor
    public Order() {
        header = "";
        OrderNo = java.util.UUID.randomUUID();
        total = 0;
        Menu[] PizzaOrder;
        phone = "";
        isDelivery = true;
    }
    //Parameterized constructor
    public Order (String header, Menu[] PizzaOrder,Double total, String phone, boolean isDelivery){
        this.OrderNo =  java.util.UUID.randomUUID();;
        this.header = header;
        this.PizzaOrder = PizzaOrder;
        this.total = total;
        this.phone = phone;
        this.isDelivery = isDelivery;
    }

    public static void writeToCsv(Menu [] order){}

    public static void readCsv(){}


    public UUID getOrderNo (){ return OrderNo;}

    public String getHeader () {return header;}

    public void setHeader() {this.header = header;}

    public Menu[] getPizzaOrder(){return PizzaOrder;}

    public void setPizzaOrder(Menu[] PizzaOrder) {this.PizzaOrder = PizzaOrder;}

    public double getTotal(){return total;}

    public void setTotal (){this.total = total;}

    public String getPhone() {
        return phone;
    }
    public boolean getIsDelivery(){
        return isDelivery;
    }
    public void setPhone(String phone){
        this.phone = phone;
    }

    public void setDelivery(boolean delivery) {
        isDelivery = delivery;
    }
}