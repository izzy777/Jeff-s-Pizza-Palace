package com.mkyong.io.csv.opencsv;

public class Payment {
    private String firstName;
    private String lastName;
    private String brand;   //Visa, mastercard, etc
    private String cardNumber;
    private int month;
    private int year;
    private int ccv;
    private String phone;

    public Payment(){
        firstName = "";
        lastName = "";
        brand = "";
        cardNumber = "";
        month = 0;
        year = 0;
        ccv = 0;
        phone = "";
    }
    public Payment(String firstName, String lastName, String brand, String cardNumber, int month, int year, int ccv, String phone){
        this.setFirstName(firstName);
        this.setLastName(lastName);
        this.setBrand(brand);
        this.setCardNumber(cardNumber);
        this.setMonth(month);
        this.setYear(year);
        this.setCcv(ccv);
        this.phone = phone;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public void setCcv(int ccv) {
        this.ccv = ccv;
    }

    public void setYear(int year) {           //make an error if it's not valid
        this.year = year;
    }

    public void setMonth(int month) {                        //make an error if it's not valid
        if(month>0 && month<13){
            this.month = month;
        }
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public int getCcv() {
        return ccv;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public String getBrand() {
        return brand;
    }

    public String getCardNumber() {
        return cardNumber;
    }
    public String getPhone(){
        return phone;
    }
    public void setPhone(String phone){
        this.phone = phone;
    }
}
