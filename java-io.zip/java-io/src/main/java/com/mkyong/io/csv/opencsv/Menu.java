package com.mkyong.io.csv.opencsv;



public class Menu {

    private double pizzaPrice;
    private double drinkPrice;

    private String foodItem;
    private String crustType;
    private char pizzaSize;

    private String drink;
    private char drinkSize;


    //If they choose pizza
    public Menu(String newFoodItem, String newCrustType, char newPizzaSize) {
        foodItem = newFoodItem;
        crustType = newCrustType;
        pizzaSize = newPizzaSize;
        pizzaPrice = getFoodPrice(newFoodItem, newCrustType, newPizzaSize);

        drink = "";
        drinkSize = ' ';
        drinkPrice = getDrinkPrice(drink, drinkSize);
    }

    //If they choose drinks
    public Menu(String newDrink, char newDrinkSize) {
        foodItem = "";
        crustType = "";
        pizzaSize = ' ';
        pizzaPrice = getFoodPrice(foodItem, crustType, pizzaSize);

        drink = newDrink;
        drinkSize = newDrinkSize;
        drinkPrice = getDrinkPrice(drink, drinkSize);
    }

    //getters and setters for all attributes
    public String getFoodItem() {
        return foodItem;
    }

    public void setFoodItem(String f) {
        foodItem = f;
    }

    public String getCrustType() {
        return crustType;
    }

    public void setCrustType(String c) {
        crustType = c;
    }

    public char getPizzaSize() {
        return pizzaSize;
    }

    public void setPizzaSize(char s) {
        pizzaSize = s;
    }

    public String getDrink() {
        return drink;
    }

    public void setDrink(String d) {
        drink = d;
    }

    public char getDrinkSize() {
        return drinkSize;
    }

    public void setDrinkSize(char s) {
        drinkSize = s;
    }

    public static double getFoodPrice(String foodName, String crust, char size) {
        double pizzaPrice = 0;

        if (foodName.equalsIgnoreCase("pizza")) {
            if (crust.equalsIgnoreCase("thin")) {
                if (size == ('s')) {
                    pizzaPrice = 5.0f;
                } else if (size == ('m')) {
                    pizzaPrice = 6.0f;
                } else {
                    pizzaPrice = 7.0f;
                }
            } else if (crust.equalsIgnoreCase("regular")) {
                if (size == ('s')) {
                    pizzaPrice = 6.0f;
                } else if (size == ('m')) {
                    pizzaPrice = 7.0f;
                } else {
                    pizzaPrice = 8.0f;
                }
            } else if (crust.equalsIgnoreCase("thick")) {
                if (size == ('s')) {
                    pizzaPrice = 7.0f;
                } else if (size == ('m')) {
                    pizzaPrice = 8.0f;
                } else {
                    pizzaPrice = 9.0f;
                }
            } else {
                pizzaPrice = 0.0f;
            }
        }//end if
        return pizzaPrice;
    }

    public static double getDrinkPrice(String drink, char size) {
        double drinkPrice = 0.0f;

        if (drink.equalsIgnoreCase("pepsi")) {
            if (size == ('s')) {
                drinkPrice = 2.0f;
            } else if (size == ('m')) {
                drinkPrice = 3.0f;
            } else {
                drinkPrice = 4.0f;
            }
        } else if (drink.equalsIgnoreCase("coca cola")) {
            if (size == ('s')) {
                drinkPrice = 2.0f;
            } else if (size == ('m')) {
                drinkPrice = 3.0f;
            } else {
                drinkPrice = 4.0f;
            }
        } else if (drink.equalsIgnoreCase("sweet tea")) {
            if (size == ('s')) {
                drinkPrice = .0f;
            } else if (size == ('m')) {
                drinkPrice = 3.0f;
            } else {
                drinkPrice = 4.0f;
            }
        }
        return drinkPrice;
    }
}
