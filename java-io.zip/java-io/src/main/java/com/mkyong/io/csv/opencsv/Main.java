package com.mkyong.io.csv.opencsv;

import com.opencsv.exceptions.CsvException;

import java.io.IOException;
import java.net.URISyntaxException;

public class Main {

    public static void main(String[] args) throws IOException, CsvException, URISyntaxException {
        CustomerList.showCustomerList();

        Customer getChloe = CustomerList.get("555-1234, x15");
        System.out.println(getChloe);

        String phoneToLookup = "333-1234";
        Customer doesNotExist = CustomerList.get(phoneToLookup); //should return null the first time, next time it won't because it was saved
        System.out.println(doesNotExist);

        if (doesNotExist == null) {
            System.out.println(phoneToLookup + " DOES NOT EXIST - ADDING " + phoneToLookup);
            Customer newCust = new Customer("Jeff", "Adkisson", "Jeff@Jeff.com", phoneToLookup, "555 Street", "Marietta", "GA", "30068", "Hurt Park", "Visa");
            CustomerList.add(newCust);
        }

        CustomerList.showCustomerList();

    }

}
