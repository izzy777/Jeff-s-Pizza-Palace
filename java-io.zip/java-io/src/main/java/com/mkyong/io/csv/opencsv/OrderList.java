package com.mkyong.io.csv.opencsv;

import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;

import java.io.*;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class OrderList {
    private static boolean isLoaded;
    private static List<Order> orders = new ArrayList<>();

    public static void add(Order order) throws CsvRequiredFieldEmptyException, CsvDataTypeMismatchException, IOException, URISyntaxException {

        if(!isLoaded) readOrdersFromCsv();

        orders.add(order);
        writeOrdersToCsv();
    }

    //finds an order by phone number, returns null if not found
    public static Order get(String phone) throws IOException, URISyntaxException {
        if(!isLoaded) readOrdersFromCsv();

        return orders.stream()
                .filter(order -> phone.equals(order.getPhone()))
                .findAny()
                .orElse(null);
    }

    public static void showOrderList() throws IOException, URISyntaxException {
        if(!isLoaded) readOrdersFromCsv();
        System.out.println("======================================");
        System.out.println("Orders in list: " + orders.size());
        for (Order order : orders)
        {
            System.out.println(order);
            System.out.println(order.getPhone() + ", " + order.getIsDelivery()); //check later
            System.out.println();
        }
        System.out.println("======================================");
        System.out.println();
        System.out.println();
    }

    private static void readOrdersFromCsv() throws IOException, URISyntaxException {
        URL resource = Order.class.getClassLoader().getResource("csv/Orders.csv");
        File file = Paths.get(resource.toURI()).toFile();
        orders = new CsvToBeanBuilder(new FileReader(file.toString()))
                .withType(Order.class)
                .build()
                .parse();

        System.out.println(orders.size() + " loaded from " + file);
        isLoaded = true;
    }

    private static void writeOrdersToCsv() throws IOException, URISyntaxException, CsvDataTypeMismatchException, CsvRequiredFieldEmptyException {

        URL resource = Order.class.getClassLoader().getResource("csv/Orders.csv");
        File file = Paths.get(resource.toURI()).toFile();

        Writer writer  = new FileWriter(file.toString());

        StatefulBeanToCsv sbc = new StatefulBeanToCsvBuilder(writer)
                .withSeparator(CSVWriter.DEFAULT_SEPARATOR)
                .build();

        sbc.write(orders);
        writer.close();

        System.out.println(orders.size() + " written to " + file);
    }

}
