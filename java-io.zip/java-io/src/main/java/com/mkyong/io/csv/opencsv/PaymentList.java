package com.mkyong.io.csv.opencsv;

import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;

import java.io.*;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class PaymentList {
    private static boolean isLoaded;
    private static List<Payment> payments = new ArrayList<>();

    public static void add(Payment payment) throws CsvRequiredFieldEmptyException, CsvDataTypeMismatchException, IOException, URISyntaxException {

        if(!isLoaded) readPaymentFromCsv();

        payments.add(payment);
        writePaymentToCsv();
    }

    //finds a payment by phone number, returns null if not found
    public static Payment get(String phone) throws IOException, URISyntaxException {
        if(!isLoaded) readPaymentFromCsv();

        return payments.stream()
                .filter(payment -> phone.equals(payment.getPhone()))
                .findAny()
                .orElse(null);
    }

    public static void showPaymentList() throws IOException, URISyntaxException {
        if(!isLoaded) readPaymentFromCsv();
        System.out.println("======================================");
        System.out.println("Payments in list: " + payments.size());
        for (Payment payment : payments)
        {
            System.out.println(payment);
            System.out.println(payment.getPhone() + ", " + payment.getLastName()); //check later
            System.out.println();
        }
        System.out.println("======================================");
        System.out.println();
        System.out.println();
    }

    private static void readPaymentFromCsv() throws IOException, URISyntaxException {
        URL resource = Payment.class.getClassLoader().getResource("csv/Payments.csv");
        File file = Paths.get(resource.toURI()).toFile();
        payments = new CsvToBeanBuilder(new FileReader(file.toString()))
                .withType(Order.class)
                .build()
                .parse();

        System.out.println(payments.size() + " loaded from " + file);
        isLoaded = true;
    }

    private static void writePaymentToCsv() throws IOException, URISyntaxException, CsvDataTypeMismatchException, CsvRequiredFieldEmptyException {

        URL resource = Payment.class.getClassLoader().getResource("csv/Payments.csv");
        File file = Paths.get(resource.toURI()).toFile();

        Writer writer  = new FileWriter(file.toString());

        StatefulBeanToCsv sbc = new StatefulBeanToCsvBuilder(writer)
                .withSeparator(CSVWriter.DEFAULT_SEPARATOR)
                .build();

        sbc.write(payments);
        writer.close();

        System.out.println(payments.size() + " written to " + file);
    }

}
