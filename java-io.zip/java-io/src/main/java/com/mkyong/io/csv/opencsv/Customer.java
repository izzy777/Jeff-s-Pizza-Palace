package com.mkyong.io.csv.opencsv;

import com.opencsv.bean.CsvBindByPosition;

public class Customer {
    @CsvBindByPosition(position = 0)
    private String firstName;

    @CsvBindByPosition(position = 1)
    private String lastName;

    @CsvBindByPosition(position = 2)
    private String email;

    @CsvBindByPosition(position = 3)
    private String phone;       //making it a string because it is a very large thing to store as a number type

    @CsvBindByPosition(position = 4)
    private String chargeAccount;

    //-----Address information
    @CsvBindByPosition(position = 5)
    private String streetAddress;

    @CsvBindByPosition(position = 6)
    private String city;

    @CsvBindByPosition(position = 7)
    private String state;

    @CsvBindByPosition(position = 8)
    private String zip;

    @CsvBindByPosition(position = 9)
    private String locationInfo;

    //-----Constructors
    public Customer(){
        firstName = "";
        lastName = "";
        email = "";
        phone = "";
        streetAddress = "";
        city = "";
        state = "";
        zip = "";
        locationInfo = "";
        chargeAccount = "";
    }
    public Customer(String firstName, String lastName, String email, String phone, String streetAddress, String city, String state, String zip, String locInfo, String chargeAccount){
        this.setFirstName(firstName);
        this.setLastName(lastName);
        this.setEmail(email);
        this.setPhone(phone);
        this.setStreetAddress(streetAddress);
        this.setCity(city);
        this.setState(state);
        this.setZip(zip);
        this.setLocationInfo(locInfo);
        this.setChargeAccount(chargeAccount);
   }


    //-----setter methods
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setCity(String city) { this.city = city; }

    public void setLocationInfo(String locationInfo) { this.locationInfo = locationInfo; }

    public void setState(String state) { this.state = state; }

    public void setStreetAddress(String streetAddress) { this.streetAddress = streetAddress; }

    public void setZip(String zip) { this.zip = zip; }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setChargeAccount(String chargeAccount) { this.chargeAccount = chargeAccount; }

    //-----getter methods
    public String getStreetAddress() {
        return streetAddress;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getCity() { return city; }

    public String getLocationInfo() { return locationInfo; }

    public String getState() { return state; }

    public String getZip() { return zip; }

    public String getChargeAccount() { return chargeAccount; }

    @Override
    public String toString() {
        return "Customer{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", phoneNumber='" + phone + '\'' +
                ", address='" + streetAddress + '\'';
    }
}
