public class MenuWithPrices {
    
}
