public class Order {
    private String header;
    private MenuWithPrices[] OrderItems = new MenuWithPrices[10];
    private double total;

    public Order(){
        header = "";
        total = 0;
    }
    //how do we want to do the constructor so that they can put in a varying number of menu items?
}