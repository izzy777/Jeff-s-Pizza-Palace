public class Payment {
    private String firstName;
    private String lastName;
    private String brand;   //Visa, mastercard, etc
    private String cardNumber;
    private int month;
    private int year;
    private int ccv;
    public boolean isValid = true;

    public Payment(){
        firstName = "";
        lastName = "";
        brand = "";
        cardNumber = "";
        month = 0;
        year = 0;
        ccv = 0;
    }
    public Payment(String firstName, String lastName, String brand, String cardNumber, int month, int year, int ccv){
        this.setFirstName(firstName);
        this.setLastName(lastName);
        this.setBrand(brand);
        this.setCardNumber(cardNumber);
        this.setMonth(month);
        this.setYear(year);
        this.setCcv(ccv);
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public void setCcv(int ccv) {
        this.ccv = ccv;
    }

    public void setYear(int year) {           //make an error if it's not valid
        this.year = year;
    }

    public void setMonth(int month) {           //make an error if it's not valid
        this.month = month;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public int getCcv() {
        return ccv;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public String getBrand() {
        return brand;
    }

    public String getCardNumber() {
        return cardNumber;
    }
    public void isValid(){
        //decides if the expiration date has passed
    }
}
