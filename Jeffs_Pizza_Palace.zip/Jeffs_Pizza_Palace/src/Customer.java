public class Customer {
    private String firstName;
    private String lastName;
    private String email;
    private String phone;       //making it a string because it is a very large thing to store as a number type
    private String address;

    public Customer(){
        firstName = "";
        lastName = "";
        email = "";
        phone = "";
        address = "";
    }
    public Customer(String firstName, String lastName, String email, String phone, String address){
        this.setFirstName(firstName);
        this.setLastName(lastName);
        this.setEmail(email);
        this.setPhone(phone);
        this.setAddress(address);
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }
}
